Welcome to the OSDU Academy Course template!

In order to successfully implement the course, you have to do following: 

1. Open the "course.xml"
    1.1. Change the title of the course. You can do that by replacing "Course name" with the 
    planned name for the course. 
    1.2. By replacing current text in <DescriptionShort>, describe the course in a few words, optimal length is one sentence. 
    1.3. By replacing current text in <DescriptionLong>, describe the course in more detail. 
    1.4. Determine the difficulty of the course. At this moment, you can pick between three alternatives: Beginner, Intermediate and Advanced. You can do this by replacing "Beginner" with a more appropriate tag. 
    1.5. Determine the domain of the course. The domain represents a field which the course can be connected to. The domains you can use are Geology, Petrouleum, Energy and Gas. If none of these are suitable, you can write just Other. You can change the domain by replacing "Geology" in the <Domain> with the one you want to use.
    1.6. Approximate the time it does take for a person to complete the course. You can do this by replacing "1-2 days" with a more suitable option. 
    1.7. Decide what knowledge should a student have in order to take the course. You can do this 
        by replacing "Prerequisite" in the <Prerequisite> tag. You can have up to 8 pre-requisites. In order to make a new one, you can copy <Prerequisite>...</Prerequisite> , paste it under previous pre-requisite and replace "..." with wanted text. 
    1.8. The courses are made up of sections and the sections are made up of lectures.  Sections and lectures require to be named. To make a new section, you have to copy:
    
    <Section title="Chapter name">
        <Lecture title="Sub-chapter name"/>
        ...
    </Section>  
    
    When you have done that, you can paste it in stead of "// Paste here".
    
    To determine chapter name you have to replace the "Chapter name" with the desired name.
    In the same manner, you can choose to re-name lecture to a more appropriate name by replacing 
    "Sub-chapter name" with it. 
    
    In order to make new slectures you can add this 
    
    <Lecture title="Sub-chapter name"/> 
    
    below the previous sub-chapter. 
    
    To add more chapters, you can repeat the process or re-use the example chapters provided. 
    
    Recommendation: You can start with an introduction chapter and end with a summary chapter.
    
    1.9. Close the "course.xml"
    
2. Open the "certification.xml" 
    Certification represents the final quiz of the course which is required by every pupil to take in order to complete the course successfully. At this moment, the quizzes are made up of only multiple-choice questions and there is only one right answer for each. You can make usual multiple-choice questions and true/false question. 
    
    2.1. Decide how much it takes to pass the test (in percent). Replace "0.8" in the <PassRate> with the desired number. Examples: If the pass rate is 50%, you should write 0.5. 
    2.2. To determine the question, you can replace "What is the question?" with your desired text. To add new question, you can copy the following and paste it in the document: 
    
    <Question title="What is the question?" correctAnswerNo="2" 
    correctAnswerDesc="This is right because...">
        <Choice>Option 1</Choice>
        <Choice>Option 2</Choice>
        <Choice>Option 3</Choice>
        ...
    </Question>
    
    2.3. Decide which answer is the right one and write the index of that number in the 
    "correctAnswerNo" instead of the current number. Notice that if the first choice is the right one, you have to write "0" and if the second choice is the right one, you have to write "1", and so on... 
    2.4. Explain why the right answer is correct by replacing the text in "correctAnswerDesc" with your explanation. 
    2.5. Make possible answers. You can make an alternative by replacing the text in <Choice> with the desired answer. You have to make at least two choices for every answer. For more details, see the examples provided. 
    2.6. Close the "certification.xml"
    
3. Open "course-name" folder. 
    Here are you introduced with two folders. The first one are for the images you use in the lectures.
    The second one is a folder containing all the sections. 
    
    Please use short names and the .png format for saving images. Save the images in the "images" folder. 
    
    Please add a thumbnail image in "images" folder and label it with "thumbail", as this picture will be the first thing user will see with your course. 
    
4. Open "sections"
    By default, there are two folders here. Both represent one specific chapter in the course. The one which is labeled with "0" represent the first chapter in the course and the one labeled with "1" represents the second chapter. In order to make a folder for new chapter, you need to make a new folder and label it with a number representing that chapter. For instance, the third chapter should be represented with the number "2". In that folder, you have to add an additional folder named "lectures" that contains the content. 
   
5. To add new lectures, open the section you want to add them in. In this example, we will use the first section (it is labeled with "0"). 
    5.1. After you have opened the section folder, open the "lectures" folder. Here you have a xml-document which contains the lecture content. 
        You can make as many as you want, but do not forget to label them accordingly. The first one    is always labeled with "0", the second with "1" and so on. The easiest way to make additional lecture is to copy already exisiting xml-document. 
        
6. To add the content to the course, you have to edit the xml-documents. You can have multiple paragraphs, figures and videos in a lecture and you can arrange them in whatever manner you please. 
    6.1. First step you have to take is to change the title of the lecture. This can be done by replacing the title text in <Title> tag with a more appropriate one. 
    6.2. To add a paragraph you have to copy and paste following on the desired location:
    
    <Paragraph>Write your text here....</Paragraph>
    
    Then you can replace "Write your text here...." with your desired text 
    
    6.3. To add an image to the lecture, you simply have to copy  and past following on the desired location:
    <Figure image="smiley.png" />
    
    Then you can replace "smiley.png" with the name of your image. Notice that you have to save the image in the "images" folder as previously mentioned.
    
    6.4. At this moment, it is only possible to add videos from YouTube. To do so, you have to find  the video you want to share on YouTube. When you have done that, copy the URL in your web browsers address bar and then replace the "watch?v=" part in the URL with "embed/". After you have done that, past the code in link here 
    
    <YouTube link="past_here" /> 
    
    and then copy the whole tag. The final step is to paste it in the desired location of the lecture. 
    
    Here is an example: 
    Original url:  https://www.youtube.com/watch?v=k9h3yPF6plg
    Replaced with embed: https://www.youtube.com/embed/k9h3yPF6plg
    
    Paste the embedded url in the <Youtube> tag:
    <YouTube link="https://www.youtube.com/embed/k9h3yPF6plg" />
        
7. Zip the folder and forward it to the admins.


If you have additional questions, please contact us!
    

    
    
        
                        
